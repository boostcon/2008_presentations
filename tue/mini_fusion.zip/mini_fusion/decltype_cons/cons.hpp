/*=============================================================================
    Copyright (c) 2008 Joel de Guzman
    Copyright (c) 2008 Dan Marsden

    Distributed under the Boost Software License, Version 1.0. (See accompanying 
    file LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)
==============================================================================*/

#if !defined(BOOST_FUSION_CONS_20080405_1229)
#define BOOST_FUSION_CONS_20080405_1229

#include "./tag_of.hpp"
#include "./cons_iterator.hpp"
#include "./intrinsic.hpp"

#include <boost/mpl/int.hpp>
#include <boost/mpl/plus.hpp>

namespace boost { namespace fusion {

    namespace extension
    {
        struct cons_tag;
    }

    struct nil
    {
        typedef extension::cons_tag tag_type;

        typedef mpl::int_<0> size;

        void get(size){}
        void get(size) const {}
    };

    template<
        typename Car, typename Cdr>
    struct cons
        : Cdr
    {
        typedef extension::cons_tag tag_type;

        typedef Car car_type;
        typedef Cdr cdr_type;

        typedef mpl::int_<Cdr::size::value + 1> size;

        car_type car;

        using Cdr::get;

        car_type& get(size)
        {
            return car;
        }

        car_type const& get(size) const
        {
            return car;
        }

        template<typename UCar, typename UCdr>
        cons(UCar&& car, UCdr&& cdr)
            : cdr_type(std::forward<UCdr>(cdr)), car(std::forward<UCar>(car))
              
        {}

        template<
            typename UCar, typename UCdr>
        cons(cons<UCar, UCdr> const& rhs)
            : cdr_type(rhs), car(rhs.car)
        {}

        template<
            typename UCar, typename UCdr>
        cons(cons<UCar, UCdr>&& rhs)
            : cdr_type(std::move(rhs.cdr)), car(std::move(rhs.car))              
        {}

        template<
            typename UCar, typename UCdr>
        cons& operator=(cons<UCar, UCdr> const& rhs)
        {
            car = rhs.car;
            static_cast<cdr_type>(*this) = rhs.cdr;
            return *this;
        }

        template<
            typename UCar, typename UCdr>
        cons& operator=(cons<UCar, UCdr>&& rhs)
        {
            car = std::move(rhs.car);
            static_cast<cdr_type>(*this) = std::move(rhs.cdr);
            return *this;
        }
    };
}}

namespace boost { namespace fusion { namespace extension {

    template<typename T>
    T& make_t();

    template<>
    struct at_impl<cons_tag>
    {
        template<typename Sequence, typename N>
        struct apply
        {
            static_assert(N::value < Sequence::size::value, "index out of bounds");

            typedef mpl::int_<Sequence::size::value - N::value> get_arg;

            typedef decltype(make_t<Sequence>().get(get_arg())) type;

            static type call(Sequence& sequence)
            {
                return sequence.get(get_arg());
            }
        };
    };

    template<>
    struct size_impl<cons_tag>
    {
        template<typename Sequence>
        struct apply
        {
            typedef typename Sequence::size type;
        };
    };

    template<>
    struct begin_impl<cons_tag>
    {
        template<typename Sequence>
        struct apply
        {
            typedef cons_iterator<Sequence> type;

            static type call(Sequence& sequence)
            {
                return type(sequence);
            }
        };
    };

    template<>
    struct end_impl<cons_tag>
    {
        template<typename Sequence>
        struct apply
        {
            typedef cons_iterator<nil> type;

            static type call(Sequence&)
            {
                return type();
            }
        };
    };
}}}

#endif
