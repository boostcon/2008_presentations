/*=============================================================================
    Copyright (c) 2008 Joel de Guzman
    Copyright (c) 2008 Dan Marsden

    Distributed under the Boost Software License, Version 1.0. (See accompanying 
    file LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)
==============================================================================*/

#if !defined(BOOST_FUSION_CONS_20080405_1229)
#define BOOST_FUSION_CONS_20080405_1229

#include "./tag_of.hpp"
#include "./cons_iterator.hpp"
#include "./intrinsic.hpp"

#include <boost/mpl/int.hpp>
#include <boost/mpl/plus.hpp>

namespace boost { namespace fusion {

    namespace extension
    {
        struct cons_tag;
    }

    struct nil
    {
        typedef extension::cons_tag tag_type;

        typedef mpl::int_<0> size;
    };

    template<
        typename Car, typename Cdr>
    struct cons
    {
        typedef extension::cons_tag tag_type;

        typedef Car car_type;
        typedef Cdr cdr_type;

        typedef mpl::plus<mpl::int_<1>, typename Cdr::size> size;

        car_type car;
        cdr_type cdr;

        template<typename UCar, typename UCdr>
        cons(UCar&& car, UCdr&& cdr)
            : car(std::forward<UCar>(car)), 
              cdr(std::forward<UCdr>(cdr))
        {}

        template<
            typename UCar, typename UCdr>
        cons(cons<UCar, UCdr> const& rhs)
            : car(rhs.car), cdr(rhs.cdr)
        {}

        template<
            typename UCar, typename UCdr>
        cons& operator=(cons<UCar, UCdr> const& rhs)
        {
            car = rhs.car;
            cdr = rhs.cdr;
            return *this;
        }
    };
}}

namespace boost { namespace fusion { namespace extension {

    template<>
    struct at_impl<cons_tag>
    {
        template<typename Sequence, typename N>
        struct apply
            : apply<Sequence, mpl::int_<N::value> >
        {};

        template<typename Sequence, int N>
        struct apply<Sequence, mpl::int_<N> >
            : apply<typename Sequence::cdr_type, mpl::int_<N-1> >
        {
            static_assert(N < Sequence::size::value, "sequence index out of bounds");

            typedef apply<typename Sequence::cdr_type, mpl::int_<N-1> > base;

            static typename base::type
            call(Sequence& sequence)
            {
                return base::call(sequence.cdr);
            }
        };

        template<typename Sequence>
        struct apply<Sequence, mpl::int_<0> >
        {
            typedef typename Sequence::car_type type;

            static type call(Sequence& sequence)
            {
                return sequence.car;
            }
        };
    };

    template<>
    struct size_impl<cons_tag>
    {
        template<typename Sequence>
        struct apply
        {
            typedef typename Sequence::size type;
        };
    };

    template<>
    struct begin_impl<cons_tag>
    {
        template<typename Sequence>
        struct apply
        {
            typedef cons_iterator<Sequence> type;

            static type call(Sequence& sequence)
            {
                return type(sequence);
            }
        };
    };

    template<>
    struct end_impl<cons_tag>
    {
        template<typename Sequence>
        struct apply
        {
            typedef cons_iterator<nil> type;

            static type call(Sequence&)
            {
                return type();
            }
        };
    };
}}}

#endif
