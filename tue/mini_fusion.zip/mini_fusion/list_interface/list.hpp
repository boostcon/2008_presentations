/*=============================================================================
    Copyright (c) 2008 Joel de Guzman
    Copyright (c) 2008 Dan Marsden

    Distributed under the Boost Software License, Version 1.0. (See accompanying 
    file LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)
==============================================================================*/

#if !defined(BOOST_FUSION_LIST_20080405_1424)
#define BOOST_FUSION_LIST_20080405_1424

#include "./cons.hpp"

#include <boost/mpl/void.hpp>

namespace boost { namespace fusion {

    template<typename T0 = mpl::void_, typename T1 = mpl::void_, typename T2 = mpl::void_>
    struct list
        : cons<T0, list<T1, T2> >
    {
        list(T0 const& u0, T1 const& u1, T2 const& u2)
            : cons<T0, list<T1, T2> >(u0, list<T1, T2>(u1, u2))
        {}
    };

    template<typename T0, typename T1>
    struct list<T0, T1, mpl::void_>
        : cons<T0, list<T1> >
    {
        list(T0 const& u0, T1 const& u1)
            : cons<T0, list<T1> >(u0, list<T1>(u1))
        {}
    };

    template<typename T0>
    struct list<T0, mpl::void_, mpl::void_>
        : cons<T0, nil>
    {
        explicit list(T0 const& u0)
            : cons<T0, nil>(u0, nil())
        {}
    };

    template<>
    struct list<mpl::void_, mpl::void_, mpl::void_>
        : nil
    {
    };
}}

#endif
