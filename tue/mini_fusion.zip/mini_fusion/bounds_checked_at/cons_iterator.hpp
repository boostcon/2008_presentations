/*=============================================================================
    Copyright (c) 2008 Joel de Guzman
    Copyright (c) 2008 Dan Marsden

    Distributed under the Boost Software License, Version 1.0. (See accompanying 
    file LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)
==============================================================================*/

#if !defined(BOOST_FUSION_CONS_ITERATOR_20080405_2029)
#define BOOST_FUSION_CONS_ITERATOR_20080405_2029

#include <boost/type_traits/is_same.hpp>
#include <boost/type_traits/add_const.hpp>

namespace boost { namespace fusion {

    namespace extension
    {
        struct cons_iterator_tag;
    }

    struct nil;

    template<typename Cons>
    struct cons_iterator
    {
        typedef extension::cons_iterator_tag tag_type;

        typedef Cons cons_type;
        cons_type& cons;

        explicit cons_iterator(Cons& cons)
            : cons(cons)
        {}
    };

    template<>
    struct cons_iterator<nil>
    {
        typedef extension::cons_iterator_tag tag_type;
        typedef nil cons_type;

        explicit cons_iterator(nil&)
        {}

        cons_iterator()
        {}
    };

    namespace extension
    {
        template<typename Tag>
        struct deref_impl;

        template<>
        struct deref_impl<cons_iterator_tag>
        {
            template<typename Iterator>
            struct apply
            {
                typedef typename Iterator::cons_type::car_type type;

                static type call(Iterator const& iterator)
                {
                    return iterator.cons.car;
                }
            };
        };

        template<typename Tag>
        struct next_impl;

        template<>
        struct next_impl<cons_iterator_tag>
        {
            template<typename Iterator>
            struct apply
            {
                typedef cons_iterator<typename Iterator::cons_type::cdr_type> type;

                static type call(Iterator const& iterator)
                {
                    return type(iterator.cons.cdr);
                }
            };
        };

        template<typename Tag>
        struct equal_to_impl;

        template<>
        struct equal_to_impl<cons_iterator_tag>
        {
            template<typename Iterator1, typename Iterator2>
            struct apply
                : is_same<
                typename add_const<typename Iterator1::cons_type>::type, 
                typename add_const<typename Iterator2::cons_type>::type>
            {};
        };
    }
}}

#endif
