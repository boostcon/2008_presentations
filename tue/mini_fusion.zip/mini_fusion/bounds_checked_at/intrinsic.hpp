/*=============================================================================
    Copyright (c) 2008 Joel de Guzman
    Copyright (c) 2008 Dan Marsden

    Distributed under the Boost Software License, Version 1.0. (See accompanying 
    file LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)
==============================================================================*/
#if !defined(BOOST_FUSION_20080405_1248)
#define BOOST_FUSION_20080405_1248

#include "./tag_of.hpp"

#include <boost/mpl/int.hpp>

namespace boost { namespace fusion {

    namespace extension {

        template<typename Tag>
        struct at_impl;

        template<typename Tag>
        struct size_impl;

        template<typename Tag>
        struct begin_impl;

        template<typename Tag>
        struct end_impl;

        template<typename Tag>
        struct deref_impl;

        template<typename Tag>
        struct next_impl;

        template<typename Tag>
        struct equal_to_impl;
    }

    namespace result_of
    {
        template<typename Sequence>
        struct size
            : extension::size_impl<typename extension::tag_of<Sequence>::type>::
          template apply<Sequence>
        {};

        template<typename Sequence, typename N>
        struct at
            : extension::at_impl<typename extension::tag_of<Sequence>::type>::
        template apply<Sequence, N>
        {};

        template<typename Sequence, int N>
        struct at_c
            : at<Sequence, mpl::int_<N> >
        {};

        template<typename Sequence>
        struct begin
            : extension::begin_impl<typename extension::tag_of<Sequence>::type>::
          template apply<Sequence>
        {};

        template<typename Sequence>
        struct end
            : extension::end_impl<typename extension::tag_of<Sequence>::type>::
          template apply<Sequence>
        {};

        template<typename Iterator>
        struct deref
            : extension::deref_impl<typename extension::tag_of<Iterator>::type>::
          template apply<Iterator>
        {};

        template<typename Iterator>
        struct next
            : extension::next_impl<typename extension::tag_of<Iterator>::type>::
          template apply<Iterator>
        {};

        template<typename Iterator1, typename Iterator2>
        struct equal_to
            : extension::equal_to_impl<typename extension::tag_of<Iterator1>::type>::
          template apply<Iterator1, Iterator2>
        {};
    }

    template<typename Sequence>
    int size(Sequence const& sequence)
    {
        typedef typename result_of::size<Sequence>::type result;
        return result();
    };

    // lvalues only for now
    template<typename N, typename Sequence>
    typename result_of::at<Sequence, N>::type
    at(Sequence& sequence)
    {
        return result_of::at<Sequence, N>::call(sequence);
    }

    // lvalues only for now
    template<int N, typename Sequence>
    typename result_of::at_c<Sequence, N>::type
    at_c(Sequence& sequence)
    {
        return result_of::at_c<Sequence, N>::call(sequence);
    }

    template<typename Sequence>
    typename result_of::begin<Sequence>::type
    begin(Sequence& sequence)
    {
        return result_of::begin<Sequence>::call(sequence);
    }

    template<typename Sequence>
    typename result_of::end<Sequence>::type
    end(Sequence& sequence)
    {
        return result_of::end<Sequence>::call(sequence);
    }

    template<typename Iterator>
    typename result_of::deref<Iterator>::type
    deref(Iterator const& iterator)
    {
        return result_of::deref<Iterator>::call(iterator);
    }

    template<typename Iterator>
    typename result_of::next<Iterator>::type
    next(Iterator const& iterator)
    {
        return result_of::next<Iterator>::call(iterator);
    }

    template<typename Iterator1, typename Iterator2>
    bool
    equal_to(Iterator1 const& iterator1, Iterator2 const& iterator2)
    {
        return typename result_of::equal_to<Iterator1, Iterator2>::type();
    }
}}

#endif
