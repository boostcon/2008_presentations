/*=============================================================================
    Copyright (c) 2008 Joel de Guzman
    Copyright (c) 2008 Dan Marsden

    Distributed under the Boost Software License, Version 1.0. (See accompanying 
    file LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)
==============================================================================*/

#if !defined(BOOST_FUSION_20080405_1246)
#define BOOST_FUSION_20080405_1246

namespace boost { namespace fusion { namespace extension {
    template<typename T>
    struct tag_of
    {
        typedef typename T::tag_type type;
    };
}}}

#endif
