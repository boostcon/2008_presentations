#include "./cons.hpp"

#include <boost/detail/lightweight_test.hpp>
#include <boost/mpl/int.hpp>

#include <string>

using namespace boost;

int main()
{
    {
        typedef fusion::cons<int, fusion::nil> one_type;

        one_type one(101, fusion::nil());

        BOOST_TEST(fusion::size(fusion::nil()) == 0);
        BOOST_TEST(fusion::size(one) == 1);

        typedef fusion::cons<std::string, one_type> two_type;
        two_type two("hello", one);

        BOOST_TEST(fusion::size(two) == 2);
    }

    {
        typedef fusion::cons<int, fusion::nil> one_type;
        one_type one(101, fusion::nil());

        BOOST_TEST(fusion::at<mpl::int_<0> >(one) == 101);
        BOOST_TEST(fusion::at_c<0>(one) == 101);

        typedef fusion::cons<std::string, one_type> two_type;
        two_type two("hello", one);

        BOOST_TEST(fusion::at<mpl::int_<0> >(two) == "hello");
        BOOST_TEST(fusion::at<mpl::int_<1> >(two) == 101);

        BOOST_TEST(fusion::at_c<0>(two) == "hello");
        BOOST_TEST(fusion::at_c<1>(two) == 101);
    }

    return boost::report_errors();
}
