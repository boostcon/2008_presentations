/*=============================================================================
    Copyright (c) 2008 Joel de Guzman
    Copyright (c) 2008 Dan Marsden

    Distributed under the Boost Software License, Version 1.0. (See accompanying 
    file LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)
==============================================================================*/

#if !defined(BOOST_FUSION_LIST_20080405_1424)
#define BOOST_FUSION_LIST_20080405_1424

#include "./cons.hpp"

namespace boost { namespace fusion {

    template<typename... Args>
    struct list;

    template<typename T, typename... Args>
    struct list<T, Args...>
        : cons<T, list<Args...> >
    {
        typedef cons<T, list<Args...> > base_type;

        template<typename U, typename... UArgs>
        explicit list(U&& t, UArgs&&... args)
            : base_type(
              std::forward<U>(t), 
              list<Args...>(std::forward<UArgs>(args)...))
        {}

        template<typename... UArgs>
        list(list<UArgs...> const& rhs)
            : base_type(rhs)
        {
            static_assert(
              list<UArgs...>::size::value == base_type::size::value, 
              "wrong sized list for converting ctor argument");
        }

        template<typename... UArgs>
        list(list<UArgs...>&& rhs)
            : base_type(std::move(rhs))
        {
            static_assert(
              list<UArgs...>::size::value == base_type::size::value, 
              "wrong sized list for move ctor argument");
        }

        template<typename... UArgs>
        list& 
        operator=(list<UArgs...>&& rhs)
        {
            static_cast<base_type>(*this) = std::move(rhs);
            return *this;
        }
    };

    template<>
    struct list<>
        : nil
    {
    };

    template<typename... UArgs>
    list<typename std::decay<UArgs>::type...>
    make_list(UArgs&&... args)
    {
        return list<typename std::decay<UArgs>::type...>(
          std::forward<UArgs>(args)...);
    }
}}

#endif
