#include "./list.hpp"

#include <boost/detail/lightweight_test.hpp>

using namespace boost;

int main()
{
    fusion::list<> l0;

    BOOST_TEST(fusion::size(l0) == 0);

    fusion::list<int> l1(101);

    BOOST_TEST(fusion::size(l1) == 1);
    BOOST_TEST(fusion::at_c<0>(l1) == 101);

    fusion::list<int, std::string> l2(101, "hello");

    BOOST_TEST(fusion::size(l2) == 2);
    BOOST_TEST(fusion::at_c<0>(l2) == 101);
    BOOST_TEST(fusion::at_c<1>(l2) == "hello");

    fusion::list<int, std::string, double> l3(101, "hello", 1.1);
    BOOST_TEST(fusion::size(l3) == 3);
    BOOST_TEST(fusion::at_c<0>(l3) == 101);
    BOOST_TEST(fusion::at_c<1>(l3) == "hello");
    BOOST_TEST(fusion::at_c<2>(l3) == 1.1);

    BOOST_TEST(fusion::deref(fusion::begin(l3)) == 101);
    BOOST_TEST(fusion::deref(fusion::next(fusion::begin(l3))) == "hello");
    BOOST_TEST(fusion::deref(fusion::next(fusion::next(fusion::begin(l3)))) == 1.1);

    fusion::list<int,int,int,int,int> long_list(0,1,2,3,4);
    BOOST_TEST(fusion::at_c<4>(long_list) == 4);

    BOOST_TEST(!fusion::equal_to(fusion::begin(l3), fusion::end(l3)));

    BOOST_TEST(fusion::equal_to(
        fusion::next(fusion::next(fusion::next(fusion::begin(l3)))), fusion::end(l3)));

    fusion::make_list(101, std::string("hello"));
    fusion::make_list(std::string("world"), 'c', 202);

    return boost::report_errors();
}
