/*=============================================================================
    Copyright (c) 2008 Joel de Guzman
    Copyright (c) 2008 Dan Marsden

    Distributed under the Boost Software License, Version 1.0. (See accompanying 
    file LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)
==============================================================================*/

#if !defined(BOOST_FUSION_LIST_20080405_1424)
#define BOOST_FUSION_LIST_20080405_1424

#include "./cons.hpp"

namespace boost { namespace fusion {

    template<typename... Args>
    struct list;

    template<typename T, typename... Args>
    struct list<T, Args...>
        : cons<T, list<Args...> >
    {
        typedef cons<T, list<Args...> > base_type;

        explicit list(T const& t, Args const&... args)
            : base_type(t, list<Args...>(args...))
        {}
    };

    template<>
    struct list<>
        : nil
    {
    };

    template<typename... Args>
    struct count;

    template<>
    struct count<>
    {
        static const int value = 0;
    };

    template<typename T, typename... Args>
    struct count<T, Args...>
    {
        static const int value = 1 + count<Args...>::value;
    };

    template<typename... T>
    struct list_size;

    template<typename... Args>
    struct list_size<list<Args...> >
        : count<Args...>
    {};
}}

#endif
